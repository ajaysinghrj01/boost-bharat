BOOST BHARAT — STARTER WEBSITE

1. Extract boost_bharat_starter.zip.
2. Open index.html in Chrome to preview it.
3. To publish a static demo, create a GitHub repository, upload index.html, then enable GitHub Pages in repository Settings > Pages.
4. A custom domain such as boostbharat.com may cost money and availability must be checked with a registrar.

IMPORTANT:
- This is a front-end demo only. It has no real login, server database, wallet, payment gateway or automated order fulfilment.
- Demo orders are stored in the current browser using localStorage and can be cleared by the user.
- Do not use this for collecting real payments or sensitive credentials.
- Before going live, have a qualified developer implement server-side authentication, secure database rules, payment-provider verification/webhooks, audit logs, refund handling, privacy policy and terms.
- Offer genuine creative/marketing services. Do not sell bot followers, fake views, likes, saves or other artificial engagement.
